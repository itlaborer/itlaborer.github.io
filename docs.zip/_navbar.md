﻿<!-- index.html -->

<body>
  <nav>
    <a href="https://throwx.cn">🐮🐮 Throwable's Blog</a>
    <a href="https://spring.throwx.cn">❤️❤️ Spring专栏</a>
  </nav>
  <div id="app">加载中......</div>
</body>