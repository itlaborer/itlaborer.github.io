﻿<!-- _sidebar.md -->

* 学习笔记
  * [docker学习笔记](/docker学习笔记.md) <!--注意这里是相对路径-->
  * [PromQL学习指南](/PromQL学习指南.md)
  * [AI知识管理工具大比拼](/AI知识管理工具大比拼.md)

* 关于老柴
  * [老柴简历](/lc.md) 
